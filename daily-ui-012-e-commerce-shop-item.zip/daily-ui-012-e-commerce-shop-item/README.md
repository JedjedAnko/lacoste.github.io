# Daily UI #012 E-Commerce Shop Item

A Pen created on CodePen.io. Original URL: [https://codepen.io/Tbgse/pen/LNBORO](https://codepen.io/Tbgse/pen/LNBORO).

Design concept for a fashion e-commerce shop item. Focus on mobile responsive design.